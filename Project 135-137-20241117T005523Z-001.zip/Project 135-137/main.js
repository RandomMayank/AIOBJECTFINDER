statusnew ="";
oname = "";
inputvalue= ";"

function setup(){
    canvas = createCanvas(500, 450);
    canvas.center()

    video = createCapture(VIDEO)
    video.size(500, 450);
    video.hide()
}

function start(){
    objectdetector = ml5.objectDetector('cocossd', modelLoaded);
    document.getElementById("status").innerHTML = "Status : Detecting Objects "
     inputvalue = document.getElementById("inputname").value
}

function modelLoaded() {
    console.log("The model has been successfully loaded")
    statusnew = true;
}

function gotResults(error, results) {
    if (error) {
        console.error(error)
    } else {
        console.log(results)
        objects = results;
    }
}

function draw(){
    image(video, 0, 0, 500, 450);
    if(statusnew != ""){
        objectdetector.detect(video, gotResults)
        for(i = 0 ; i < objects.length ; i++){
            document.getElementById("numberofobjects").innerHTML = " Number of Objects " + objects.length
            object_name = objects[i].label
            percent = floor(objects[i].confidence * 100)
            position_x = objects[i].x
            position_y = objects[i].y
            width = objects[i].width
            height = objects[i].height

            if(object_name == inputname){
                video.stop();
              objectdetector.detect(video);       
              document.getElementById("status").innerHTML = "Status : Objects Detected "                        
            }
        }
    }
    
}
